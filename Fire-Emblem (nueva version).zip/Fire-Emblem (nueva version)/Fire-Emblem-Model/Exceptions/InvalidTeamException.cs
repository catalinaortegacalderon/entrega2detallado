namespace ConsoleApp1.Exceptions;

public class InvalidTeamException : ApplicationException
{
    
}