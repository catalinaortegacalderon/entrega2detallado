namespace ConsoleApp1.DataTypes;

public enum Gender
{
    Male, Female
}