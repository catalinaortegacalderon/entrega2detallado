namespace ConsoleApp1.DataTypes;

public enum StatType
{
    Atk, Res, Def, Spd, None
}