namespace ConsoleApp1.DataTypes;

public enum Weapon
{
    Axe, Sword, Bow, Magic, Lance, Empty
}