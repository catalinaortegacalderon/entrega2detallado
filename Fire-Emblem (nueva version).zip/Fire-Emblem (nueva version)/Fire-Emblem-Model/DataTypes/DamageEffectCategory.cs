namespace ConsoleApp1.DataTypes;

public enum DamageEffectCategory
{
    All, FirstAttack, FollowUp
}