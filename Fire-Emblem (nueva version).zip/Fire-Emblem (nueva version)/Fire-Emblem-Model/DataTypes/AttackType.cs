namespace ConsoleApp1.DataTypes;

public enum AttackType
{
    FirstAttack, SecondAttack, FollowUp
}